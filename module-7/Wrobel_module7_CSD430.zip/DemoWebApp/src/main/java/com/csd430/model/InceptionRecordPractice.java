package com.csd430.model;

import java.io.Serializable;

/**
 * Class name: InceptionRecordPractice
 * Description: JavaBean encapsulating...
 */

public class InceptionRecordPractice implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String category;
	private String name;
	private String role;
	private int dreamDepth;
	private String description;
	
	public InceptionRecordPractice() {
	}
	
	public InceptionRecordPractice(String category, String name, String role, int dreamDepth, String description) {
		this.category = category;
		this.name = name;
		this.role = role;
		this.dreamDepth = dreamDepth;
		this.description = description;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getDreamDepth() {
		return dreamDepth;
	}
	public void setDreamDepth(int dreamDepth) {
		this.dreamDepth = dreamDepth;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
