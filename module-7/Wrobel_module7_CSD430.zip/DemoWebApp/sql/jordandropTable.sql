USE CSD430;

DROP TABLE IF EXISTS jordanmoviesdata;